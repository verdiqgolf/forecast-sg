export const mockRounds = [
  {
    id: "r_001",
    course: "Franklin CC",
    date: "2025-06-14",
    score: 82,
    strokesGained: -3.2,
    details: {
      tee: -0.5,
      approach: -1.2,
      short: -0.7,
      putting: -0.8,
    },
  },
  {
    id: "r_002",
    course: "Southwick Muni",
    date: "2025-06-07",
    score: 79,
    strokesGained: -0.8,
    details: {
      tee: 0.4,
      approach: -0.3,
      short: 0.2,
      putting: -1.1,
    },
  },
];
